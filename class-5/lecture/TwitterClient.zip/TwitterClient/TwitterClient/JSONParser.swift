//
//  JSONParser.swift
//  TwitterClient
//
//  Created by Adam Wallraff on 9/9/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

import Foundation

typealias JSONParserCompletion = (Bool, [Tweet]?) -> ()

class JSONParser{
    
    static var sampleJSONData : Data{
        guard let tweetJSONPath = Bundle.main.url(forResource: "Tweet", withExtension: "json") else { fatalError("Tweet.json does not exist.") }
        
        do{
            let tweetJSONData = try Data(contentsOf: tweetJSONPath)
            return tweetJSONData
            
        }catch {
            fatalError("Failed to convert JSON to Data.")
        }
    }
    
    class func tweetsFrom(data: Data, completion: JSONParserCompletion){
        do {
            
            if let rootObject = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [[String: AnyObject]]{
                var tweets = [Tweet]()
                for tweetJSON in rootObject{
                    if let tweet = Tweet(json: tweetJSON){
                        tweets.append(tweet)
                    }
                }
                completion(true, tweets)
            }
        }
        catch {
            print("Error Serializing JSON")
            completion(false, nil)
        }
    }
}
