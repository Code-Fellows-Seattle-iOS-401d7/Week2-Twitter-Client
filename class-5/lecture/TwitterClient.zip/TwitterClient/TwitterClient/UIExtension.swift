//
//  UIExtension.swift
//  TwitterClient
//
//  Created by Adam Wallraff on 9/13/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

import UIKit

extension UIResponder{
    class func identifier() -> String{
        return String(describing: self)
    }
}
