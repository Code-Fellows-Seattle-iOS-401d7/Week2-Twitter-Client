//
//  TweetDetailViewController.swift
//  TwitterClient
//
//  Created by Adam Wallraff on 9/12/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

import UIKit

class TweetDetailViewController: UIViewController {
    
    var tweet: Tweet!
    
    @IBOutlet weak var usernameLabel: UILabel!
    @IBOutlet weak var tweetTextLabel: UILabel!
    
    @IBOutlet weak var profileImageView: UIImageView!


    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        setupAppearance()
        setupTweet()
    }
    
    @IBAction func imageTapped(_ sender: AnyObject) {
        
        performSegue(withIdentifier: UserTimelineViewController.identifier(), sender: sender)
    }
    
    func setupAppearance(){
        profileImageView.clipsToBounds = true
        profileImageView.layer.cornerRadius = 30.0
    }
    
    func setupTweet(){
            if let user = tweet.user {
                
                self.navigationItem.title = "Tweet"
                self.tweetTextLabel.text = tweet.text
                self.usernameLabel.text = "@\(user.name)"
                
                self.profileImage(key: user.profileImageURL, completion: { (image) -> () in
                    self.profileImageView.image = image
                })
            }
    }
    
    func profileImage(key: String, completion: @escaping (UIImage?) -> ())
    {
        if let image = SimpleCache.shared.image(key: key) {
            completion(image)
            return
        }
        
        API.shared.GETImage(urlString: key) { (image) -> () in
            if let image = image {
                completion(image)
            }
        }
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)

        if segue.identifier == UserTimelineViewController.identifier() {
            let userTimelineViewController = segue.destination as! UserTimelineViewController
            userTimelineViewController.tweet = self.tweet
        }

    }
    
}
