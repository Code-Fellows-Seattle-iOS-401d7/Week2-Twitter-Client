//
//  API.swift
//  TwitterClient
//
//  Created by Adam Wallraff on 9/12/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

import Foundation
import Accounts
import Social

typealias accountCompletion = (ACAccount?)->()
typealias userCompletion = (User?)->()
typealias tweetsCompletion = ([Tweet]?)->()
typealias imageCompletion = (UIImage?) -> ()

class API {

    static let shared = API()
    var account: ACAccount?
    
    
    private func login(completion:@escaping accountCompletion){
        
        let accountStore = ACAccountStore()
        
        let accountType = accountStore.accountType(withAccountTypeIdentifier: ACAccountTypeIdentifierTwitter)
        
        accountStore.requestAccessToAccounts(with: accountType, options: nil) { (success, error) in
            if error != nil {
                print("ERROR: Request access to accounts returned an error.")
                completion(nil)
                return
            }
            
            if success {
                
                if let account = accountStore.accounts(with: accountType).first as? ACAccount{
                    completion(account)
                    return
                }

                print("ERROR: No twitter accounts were found on this device.")
                completion(nil)
                return
            }
            
            print("ERROR: This app requires access to the Twitter Accounts.")
            completion(nil)
            return
        }
    }
    
    private func GETOAuthUser(completion: @escaping userCompletion)
    {
        let url = URL(string: "https://api.twitter.com/1.1/account/verify_credentials.json")
        
        if let request = SLRequest(forServiceType: SLServiceTypeTwitter,
                                   requestMethod: .GET,
                                   url: url,
                                   parameters: nil) {
            
            request.account = self.account
            
            request.perform(handler: { (data, response, error) in
                if let _ = error {
                    print("ERROR: SLRequest type GET for /1.1/account/verify_credentials.json could not be completed.")
                    completion(nil)
                    return
                }
                
                guard let response = response else { completion(nil); return }
                guard let data = data else { completion(nil); return }
                
                switch response.statusCode{
                case 200...299:
                    do {
                        if let userJSON = try JSONSerialization.jsonObject(with: data, options: .mutableContainers) as? [String : AnyObject] {
                            completion(User(json: userJSON))
                            return
                        }
                    } catch {
                        print("ERROR: NSJSONSerialization.JSONObjectWithData was unable to de-serialize JSON object.")
                    }
                case 400...499:
                    print("ERROR: SLRequest type GET for /1.1/account/verify_credentials.json returned status code \(response.statusCode) [user input error].")
                case 500...599:
                    print("ERROR: SLRequest type GET for /1.1/account/verify_credentials.json returned status code \(response.statusCode) [server side error].")
                default:
                    print("ERROR: SLRequest type GET for /1.1/account/verify_credentials.json returned status code \(response.statusCode) [unknown error].")
                }
                completion(nil)
                
            })
        }
    }
    
    private func updateTimeline(url: String, completion: @escaping tweetsCompletion)
    {
        if let request = SLRequest(forServiceType: SLServiceTypeTwitter,
                                   requestMethod: .GET,
                                   url: URL(string: url),
                                   parameters: nil) {

            request.account = self.account
            
            request.perform(handler: { (data, response, error) in
                if let _ = error {
                    print("ERROR: SLRequest type GET for /1.1/statuses/home_timeline.json could not be completed.")
                    completion(nil)
                    return
                }
                
                guard let response = response else { completion(nil); return }
                guard let data = data else { completion(nil); return }
                
                switch response.statusCode {
                case 200...299:
                    JSONParser.tweetsFrom(data: data, completion: { (success, tweets) in
                        completion(tweets)
                    })
                case 400...499:
                    print("ERROR: SLRequest type GET for /1.1/statuses/home_timeline.json returned status code \(response.statusCode) [user input error].")
                    
                case 500...599:
                    print("ERROR: SLRequest type GET for /1.1/statuses/home_timeline.json returned status code \(response.statusCode) [server side error].")
                    
                default:
                    print("ERROR: SLRequest type GET for /1.1/statuses/home_timeline.json returned status code \(response.statusCode) [unknown error].")
                }
                
                completion(nil)

            })

            
        }

    }
    
    func GETTweets(completion:@escaping tweetsCompletion){
        if self.account != nil {
            self.updateTimeline(url: "https://api.twitter.com/1.1/statuses/home_timeline.json", completion: completion)
        } else {
            self.login(completion: { (account) in
                if let account = account {
                    API.shared.account = account
                    self.updateTimeline(url: "https://api.twitter.com/1.1/statuses/home_timeline.json", completion: completion)
                } else { print("Account is nil.") }
            })
        }
    }
    
    func GETUserTweets(username: String, completion:@escaping tweetsCompletion)
    {
        self.updateTimeline(url: "https://api.twitter.com/1.1/statuses/user_timeline.json?screen_name=\(username)", completion: completion)
    }
    
    func GETImage(urlString: String, completion: @escaping imageCompletion)
    {
        print(urlString)
        OperationQueue().addOperation {
            guard let url = URL(string: urlString) else { return }
            
            do{
                let data = try Data(contentsOf: url)
                guard let image = UIImage(data: data) else { return }
                
                // Return on the main thread.
                OperationQueue.main.addOperation {
                    completion(image)
                }
                
            }catch {
                print("There was an error getting the Data from URL for UIImage.")
                print(error)
                OperationQueue.main.addOperation {
                    completion(nil)
                }
            }

        }
    }
}
