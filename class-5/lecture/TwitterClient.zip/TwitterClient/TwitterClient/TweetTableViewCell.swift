//
//  TweetTableViewCell.swift
//  TwitterClient
//
//  Created by Adam Wallraff on 9/12/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

import UIKit

class TweetTableViewCell: UITableViewCell {

    @IBOutlet weak var tweetLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
