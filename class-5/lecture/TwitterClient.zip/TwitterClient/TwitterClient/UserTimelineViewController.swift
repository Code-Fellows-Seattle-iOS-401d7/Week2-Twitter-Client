//
//  UserTimelineViewController.swift
//  TwitterClient
//
//  Created by Adam Wallraff on 9/13/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

import UIKit

class UserTimelineViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    var tweet: Tweet?
    
    var tweets = [Tweet]() {
        didSet {
            self.tableView.reloadData()
        }
    }
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
        
        setupViewController()
        setupTableView()
    }
    
    func setupViewController(){
        if let tweet = self.tweet, let user = tweet.user {
            self.navigationItem.title = user.screenName
            self.update(screenName: user.screenName)
        }
    }
    
    func setupTableView()
    {
        self.tableView.estimatedRowHeight = 100
        self.tableView.rowHeight = UITableViewAutomaticDimension
        self.tableView.register(UINib(nibName: "TweetCell", bundle: nil), forCellReuseIdentifier: TweetCell.identifier())
        self.tableView.dataSource = self
        
    }
    
    func update(screenName: String)
    {
        API.shared.GETUserTweets(username: screenName) { (tweets) -> () in
            guard let tweets = tweets else { return }
            OperationQueue.main.addOperation {
                self.tweets = tweets
            }
        }
    }
    
}

extension UserTimelineViewController: UITableViewDataSource
{
    
    func configureCellFor(indexPath: IndexPath) -> UITableViewCell
    {
        let tweetCell = self.tableView.dequeueReusableCell(withIdentifier: TweetCell.identifier(), for: indexPath) as! TweetCell
        
        tweetCell.tweet = self.tweets[indexPath.row]
        
        return tweetCell
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tweets.count
    }

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        return configureCellFor(indexPath: indexPath)
    }

}
